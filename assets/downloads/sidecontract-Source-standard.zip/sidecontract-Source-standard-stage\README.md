<div align="center">

<a href="https://robbygrean.github.io/sidecontract/">
  <img src="./assets/readme/sidecontract-hero.svg" alt="sidecontract — โปรแกรมสร้างเอกสาร Word แบบออฟไลน์ สำหรับงานจัดซื้อจัดจ้างและเบิกเงินเดือน" width="100%">
</a>

<p>
  <img src="https://img.shields.io/badge/WINDOWS-OFFLINE-36cfe4?style=for-the-badge&amp;labelColor=101d39" alt="Windows · Offline">
  <img src="https://img.shields.io/badge/WORKFLOWS-2-b499ff?style=for-the-badge&amp;labelColor=101d39" alt="2 workflows">
  <img src="https://img.shields.io/badge/OUTPUT-WORD-ef74bc?style=for-the-badge&amp;labelColor=101d39" alt="Word output">
  <img src="https://img.shields.io/badge/LOCAL_DATA-NO_CLOUD-f2cd7d?style=for-the-badge&amp;labelColor=101d39" alt="Local data · No cloud">
</p>

### งานเอกสารสองแบบ จบในโปรแกรมเดียว

โปรแกรมช่วยกรอกข้อมูลและสร้างเอกสาร **Word** สำหรับ Windows<br>
**จัดซื้อจัดจ้างและสัญญา · เบิกเงินเดือน**<br>
กรอกหรือโหลดข้อมูล → ตรวจสอบ → สร้างเอกสาร พร้อมเก็บผลลัพธ์ไว้ในเครื่อง

<a href="https://robbygrean.github.io/sidecontract/">
  <img src="./assets/readme/download-button.svg" alt="ดาวน์โหลดโปรแกรม sidecontract — ไปยังหน้าดาวน์โหลด" width="420">
</a>

**[เปิดเว็บไซต์และดาวน์โหลดโปรแกรม](https://robbygrean.github.io/sidecontract/)**

<p>
  <a href="https://robbygrean.github.io/sidecontract/guide.html"><img src="https://img.shields.io/badge/READ-THAI_GUIDE-78dfe9?style=for-the-badge&amp;labelColor=101d39" alt="อ่านคู่มือภาษาไทย"></a>
  <a href="./assets/downloads/sidecontract-Source.zip"><img src="https://img.shields.io/badge/EXPLORE-SOURCE_CODE-c1a0ff?style=for-the-badge&amp;labelColor=101d39" alt="ดาวน์โหลด Source code"></a>
</p>

[ความสามารถ](#ความสามารถ) · [เริ่มใช้งาน](#เริ่มใช้งาน) · [ภาพโปรแกรมจริง](#ภาพโปรแกรมจริง) · [ดาวน์โหลดและคู่มือ](#ดาวน์โหลดและคู่มือ)

</div>

<img src="./assets/readme/divider.svg" width="100%" alt="">

## ความสามารถ

| จัดซื้อจัดจ้างและสัญญา | เบิกเงินเดือน |
| :--- | :--- |
| กรอกข้อมูลสำหรับงานจัดซื้อจัดจ้างและสัญญา | กรอกข้อมูลสำหรับงานเบิกเงินเดือน |
| ตรวจรายการเอกสารก่อนสร้างจากแม่แบบ Word | เลือกงวดและรายการเอกสารที่ต้องการสร้าง |
| เก็บ Template ข้อมูลและผลลัพธ์ของงานจัดจ้างแยกไว้ | เก็บ Template ข้อมูลและผลลัพธ์ของงานเงินเดือนแยกไว้ |

**ใช้ข้อมูลร่วมได้** — ชื่อ ที่อยู่ และข้อมูลกรรมการที่เกี่ยวข้องสามารถนำไปใช้กับอีกแท็บผ่านการโหลด Template โดยตรวจรายงานก่อนยืนยันการนำเข้าข้ามงาน

**ทำงานในเครื่อง** — ข้อมูลและเอกสารทำงานแบบ local ไม่ต้องใช้ npm หรือระบบ cloud เพื่อใช้งานโปรแกรม

**เก็บข้อมูลไว้ใช้ต่อ** — บันทึก Template เพื่อโหลดข้อมูลในฟอร์มกลับมาใช้ครั้งถัดไป โดยงวดเบิก รายการเอกสาร และ Output ยังคงแยกตามแท็บ

## เริ่มใช้งาน

1. ไปที่ **[หน้าดาวน์โหลด sidecontract](https://robbygrean.github.io/sidecontract/)** แล้วดาวน์โหลด Installer
2. แตกไฟล์ ZIP และเปิด **`sidecontract-Setup.exe`**
3. เปิดโปรแกรม แล้วเลือกแท็บ **จัดซื้อจัดจ้างและสัญญา** หรือ **เบิกเงินเดือน**
4. กรอกข้อมูลหรือโหลด Template ตรวจสอบข้อมูล แล้วสร้างเอกสาร Word

> [!TIP]
> คู่มือรวมวิธีติดตั้ง คำเตือนจาก Chrome/Windows การโหลด Template ข้ามงาน และการสร้างเอกสารไว้แล้ว → **[อ่านคู่มือภาษาไทย](https://robbygrean.github.io/sidecontract/guide.html)**

<img src="./assets/readme/divider.svg" width="100%" alt="">

## อัปเดตโปรแกรม

รุ่นเริ่มต้น **1.0.0** รวมระบบจัดซื้อจัดจ้างและเบิกเงินเดือน สร้างเอกสาร Word จาก Template แยกข้อมูลของแต่ละงาน และตรวจอัปเดตจาก repository sidecontract ของตัวเองเท่านั้น

- **มีปุ่มอัปเดตแล้ว:** กด **อัปเดตโปรแกรม** มุมขวาบนเหนือสองแท็บ ถัดจาก **ข้อมูลโปรแกรม** ตรวจสอบและยืนยันดาวน์โหลด จากนั้นบันทึกงานก่อนปิด ทำตามตัวติดตั้ง และเปิดโปรแกรมใหม่
- **ติดตั้ง sidecontract ครั้งแรก:** ดาวน์โหลด [Installer ZIP](./assets/downloads/sidecontract-Installer.zip) แตกไฟล์ แล้วรัน `sidecontract-Setup.exe` โปรแกรมติดตั้งลง `%LOCALAPPDATA%\sidecontract` และเก็บข้อมูลแยกจากแอปอื่น

ระบบตรวจ checksum ของไฟล์ก่อนติดตั้ง ตัวติดตั้งสำรอง Template เดิมและเก็บข้อมูลใน Data/Output หากดาวน์โหลดไม่สำเร็จ โปรแกรมเดิมยังใช้งานต่อได้ การสร้างเอกสารทำงานออฟไลน์ ส่วนการตรวจและดาวน์โหลดอัปเดตต้องใช้อินเทอร์เน็ต

หลังติดตั้ง เปิดผ่าน shortcut ของ sidecontract แล้วกด **ข้อมูลโปรแกรม** ตรวจเวอร์ชันและตำแหน่งไฟล์ที่เปิดจริง หากเปิด `.exe` จากโฟลเดอร์เก่าอีกชุด อาจยังเห็นรุ่นเดิม

## ดาวน์โหลดหรือติดตั้งแล้วเจอคำเตือน

### Chrome เตือนไฟล์มีความเสี่ยง

1. เปิดรายการดาวน์โหลด แล้วคลิกลูกศรหรือรายการไฟล์ที่มีคำเตือน
2. ตรวจแหล่งที่มาเป็น **RobbyGrean/sidecontract** และชื่อไฟล์ **sidecontract-Installer.zip**
3. เมื่อตรวจสอบและเชื่อถือแล้ว คลิก **ดาวน์โหลดไฟล์ที่น่าสงสัย** (บางรุ่นใช้ **Keep / เก็บไว้** หรือ **Keep anyway / เก็บไว้ต่อไป**)
4. แตก ZIP ก่อนเปิด **sidecontract-Setup.exe**

| เปิดรายการที่ถูกเตือน | เลือกดาวน์โหลดต่อ |
| :---: | :---: |
| ![รายการดาวน์โหลด Chrome](./assets/guide/chrome-warning-history.png) | ![ปุ่มดาวน์โหลดไฟล์ที่น่าสงสัย](./assets/guide/chrome-warning-detail.png) |

ภาพ Chrome เป็นตัวอย่างประกอบเท่านั้น ให้ตรวจชื่อ **sidecontract-Installer.zip** ก่อนดาวน์โหลด

### Windows protected your PC — More info → Run anyway

1. เมื่อขึ้น **Windows protected your PC** คลิก **More info / ข้อมูลเพิ่มเติม**
2. ตรวจชื่อแอปให้เป็น **sidecontract-Setup.exe** จากไฟล์ที่ดาวน์โหลดจากเว็บไซต์ทางการ
3. คลิก **Run anyway / เรียกใช้ต่อไป** ที่ปรากฏขึ้น แล้วทำตามหน้าต่างติดตั้ง

![ตัวอย่างสองขั้นตอนบน Windows: คลิก More info แล้วคลิก Run anyway ที่วงไว้](./assets/guide/windows-smartscreen.png)

SmartScreen อาจเตือนเมื่อแอปยังไม่มีชื่อเสียงเพียงพอหรือไม่มีลายเซ็นที่ระบบรู้จัก ทำต่อเฉพาะไฟล์ที่ตรวจสอบและเชื่อถือ หากไม่มีปุ่ม Run anyway ให้ติดต่อผู้ดูแลเครื่อง เพราะนโยบายองค์กรอาจไม่อนุญาต

[ดูภาพและขั้นตอนบนเว็บไซต์](https://robbygrean.github.io/sidecontract/#download-help) · [อ่านคู่มือการติดตั้ง](https://robbygrean.github.io/sidecontract/guide.html#smartscreen)

<img src="./assets/readme/divider.svg" width="100%" alt="">

## จากข้อมูลสู่เอกสาร Word

![Workflow ของผู้ใช้ sidecontract ตั้งแต่เลือกงานจนถึงสร้างเอกสาร](./assets/readme/sidecontract-user-workflow.svg)

<details>
<summary><strong>ดูการเชื่อมโยงข้อมูลภายในและหลักการของ Template</strong></summary>

<br>

![การเชื่อมโยงข้อมูลภายในของ sidecontract](./assets/readme/sidecontract-data-flow.svg)

- การโหลด Template ข้ามงานใช้ข้อมูลร่วมที่เกี่ยวข้องกับปลายทาง
- งวดเบิก รายการเอกสาร Template ที่บันทึก และโฟลเดอร์ผลลัพธ์ยังแยกตามงาน
- การบันทึก Template คือการเก็บข้อมูลในฟอร์มไว้ใช้ครั้งต่อไป ไม่ใช่การแก้แม่แบบ Word ต้นฉบับ

</details>

> [!IMPORTANT]
> ตรวจเอกสาร Word ก่อนนำไปใช้จริง ช่องที่ไม่ได้กรอกอาจถูกแทนด้วยจุดตามกติกาของระบบ

<img src="./assets/readme/divider.svg" width="100%" alt="">

## ดาวน์โหลดและคู่มือ

| ต้องการทำอะไร | ไปที่นี่ |
| :--- | :--- |
| **ดาวน์โหลดโปรแกรมสำหรับ Windows** | **[เปิดหน้าดาวน์โหลด](https://robbygrean.github.io/sidecontract/)** |
| ดาวน์โหลดไฟล์ติดตั้งโดยตรง | [sidecontract-Installer.zip](./assets/downloads/sidecontract-Installer.zip) |
| เปิดตัวติดตั้งโดยไม่ต้องแตก ZIP | [sidecontract-Setup.exe](./assets/downloads/sidecontract-Setup.exe) |
| อ่านวิธีติดตั้งและใช้งาน | [คู่มือบนเว็บไซต์](https://robbygrean.github.io/sidecontract/guide.html) · [คู่มือใน repository](./GUIDE.md) |
| ศึกษา Source code | [sidecontract-Source.zip](./assets/downloads/sidecontract-Source.zip) |
| ดูเนื้อหาและข้อกำหนดเว็บไซต์ | [SITE_CONTENT_BRIEF.md](./SITE_CONTENT_BRIEF.md) |

**การอัปเดต:** รุ่น 1.0.0 เป็นต้นไปมีปุ่ม **อัปเดตโปรแกรม** ใช้ได้จากทั้งสองแท็บ อ่านขั้นตอนใน [หัวข้ออัปเดตโปรแกรม](#อัปเดตโปรแกรม)

<details>
<summary><strong>สำหรับผู้พัฒนา — โครงสร้าง repository</strong></summary>

```text
assets/
├─ downloads/       ไฟล์ Installer และ Source สำหรับดาวน์โหลด
├─ guide/           ภาพประกอบคำเตือนการดาวน์โหลด
└─ readme/          HERO ปุ่มดาวน์โหลด และแผนภาพสำหรับ README
Config/             config ของ workflow และ Template
Modules/            โมดูลจัดซื้อจัดจ้าง
Shared/             core, renderer และการโอนข้อมูลระหว่าง Template
Template/           Template Word ของทั้งสอง workflow
sidecontract*.cs       source ของตัวโปรแกรมและตัวติดตั้ง
GUIDE.md            คู่มือฉบับอ่านง่าย
SITE_CONTENT_BRIEF.md brief เนื้อหาจริงและคำสั่งสำหรับปรับเว็บไซต์
guide.html          คู่มือบนเว็บไซต์
index.html          เว็บไซต์หลัก
README.md           หน้าสรุปโครงการ
```

</details>

<br>

<div align="center">

### sidecontract

**เตรียมข้อมูล · ตรวจให้ครบ · สร้างเอกสาร Word**

<a href="https://robbygrean.github.io/sidecontract/"><img src="./assets/readme/download-button.svg" alt="ดาวน์โหลดโปรแกรม sidecontract" width="360"></a>

พัฒนาโดย [RobbyGrean](https://github.com/RobbyGrean)

</div>
